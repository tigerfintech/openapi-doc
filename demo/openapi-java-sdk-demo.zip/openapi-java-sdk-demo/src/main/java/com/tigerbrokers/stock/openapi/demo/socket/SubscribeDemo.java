/* Licensed under Apache-2.0 2025. */
package com.tigerbrokers.stock.openapi.demo.socket;

import com.tigerbrokers.stock.openapi.client.config.ClientConfig;
import com.tigerbrokers.stock.openapi.client.socket.WebSocketClient;
import com.tigerbrokers.stock.openapi.client.struct.enums.Subject;
import com.tigerbrokers.stock.openapi.client.util.ApiLogger;
import com.tigerbrokers.stock.openapi.demo.TigerConfigManager;
import com.tigerbrokers.stock.openapi.demo.TigerConfigManager.Config;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class SubscribeDemo {

  private static WebSocketClient client;

  static void init() {

    TigerConfigManager configManager = new TigerConfigManager();
    ClientConfig clientConfig = configManager.getClientConfig();

    clientConfig.isSslSocket = false;
    client = WebSocketClient.getInstance();
    if (Config.getCustomSocketUrl() != null) {
      client.useFixedSocketUrl(Config.getCustomSocketUrl());
    }
    client.clientConfig(clientConfig).apiComposeCallback(new DefaultApiComposeCallback());

    ApiLogger.setEnabled(true);
    ApiLogger.setErrorEnabled(true);
    ApiLogger.setWarnEnabled(true);
    ApiLogger.setInfoEnabled(true);
    ApiLogger.setDebugEnabled(true);
  }

  public static void main(String[] args) throws Exception {
    SubscribeDemo.init();

    Set<String> symbols = new HashSet<>();
    symbols.add("TSLA");
    symbols.add("AAPL");
    symbols.add("00700");

    try {
      client.connect();
      subscribe(symbols, symbols, symbols, symbols);
      TimeUnit.SECONDS.sleep(60000);
    } finally {
      cancelSubscribe(symbols, symbols, symbols, symbols);
    }
  }

  public static void subscribe(
      Set<String> symbols,
      Set<String> depthSymbols,
      Set<String> tradeTickSymbols,
      Set<String> klineSymbols) {

    // 订阅 订单/资产/持仓/订单执行报告
    client.subscribe(Subject.OrderStatus);
    client.subscribe(Subject.Asset);
    client.subscribe(Subject.Position);

    // 订阅行情
    if (symbols != null && !symbols.isEmpty()) {
      client.subscribeQuote(symbols);
    }
    // 订阅深度行情
    if (depthSymbols != null && !depthSymbols.isEmpty()) {
      client.subscribeDepthQuote(depthSymbols);
    }
    // 订阅逐笔行情
    if (tradeTickSymbols != null && !tradeTickSymbols.isEmpty()) {
      client.subscribeTradeTick(tradeTickSymbols);
    }
    // 订阅K线
    if (klineSymbols != null && !klineSymbols.isEmpty()) {
      client.subscribeKline(klineSymbols);
    }
    // 查询订阅详情
    client.getSubscribedSymbols();
  }

  private static void cancelSubscribe(
      Set<String> symbols,
      Set<String> depthSymbols,
      Set<String> tradeTickSymbols,
      Set<String> klineSymbols) {
    // 取消订阅 订单/资产/持仓/订单执行报告
    client.cancelSubscribe(Subject.Asset);
    client.cancelSubscribe(Subject.Position);
    client.cancelSubscribe(Subject.OrderStatus);
    //    client.cancelSubscribe(Subject.OrderTransaction);
    // 取消全部标的（股票，期权，期货）的行情订阅
    if (symbols != null && !symbols.isEmpty()) {
      client.cancelSubscribeQuote(symbols);
    }
    // 取消全部标的（股票，期货）的深度行情订阅
    if (depthSymbols != null && !depthSymbols.isEmpty()) {
      client.cancelSubscribeDepthQuote(depthSymbols);
    }
    // 取消全部标的（股票，期货）的逐笔行情订阅
    if (tradeTickSymbols != null && !tradeTickSymbols.isEmpty()) {
      client.cancelSubscribeTradeTick(tradeTickSymbols);
    }
    // 取消全部标的（股票，期货）的K线订阅
    if (klineSymbols != null && !klineSymbols.isEmpty()) {
      client.cancelSubscribeKline(klineSymbols);
    }
  }
}
