/* Licensed under Apache-2.0 2025. */
package com.tigerbrokers.stock.openapi.demo.trade;

import com.tigerbrokers.stock.openapi.client.https.domain.contract.model.ContractModel;
import com.tigerbrokers.stock.openapi.client.https.domain.contract.model.ContractsModel;
import com.tigerbrokers.stock.openapi.client.https.request.contract.ContractRequest;
import com.tigerbrokers.stock.openapi.client.https.request.contract.ContractsRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteContractRequest;
import com.tigerbrokers.stock.openapi.client.https.response.contract.ContractResponse;
import com.tigerbrokers.stock.openapi.client.https.response.contract.ContractsResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteContractResponse;
import com.tigerbrokers.stock.openapi.client.struct.enums.SecType;
import com.tigerbrokers.stock.openapi.demo.BasicOpenAPI;
import com.tigerbrokers.stock.openapi.demo.TigerConfigManager.Config;
import java.util.Arrays;
import java.util.List;

public class ContractDemo {

  public static void main(String[] args) {
    contractRequest("AAPL");
    contractsRequest(Arrays.asList("AAPL", "TSLA"));
    quoteOptContractRequest("TSLA", "20250919");
    quoteWarContractRequest("00700");
  }

  /** 获取单个合约信息 */
  public static ContractResponse contractRequest(String symbol) {
    ContractRequest request =
        ContractRequest.newRequest(new ContractModel(symbol), Config.getAccountInfo());
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 批量获取合约信息 */
  public static ContractsResponse contractsRequest(List<String> symbols) {
    ContractsRequest request = ContractsRequest.newRequest(new ContractsModel(symbols));
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取期权合约信息 */
  public static QuoteContractResponse quoteOptContractRequest(String symbol, String expiry) {
    QuoteContractRequest request = QuoteContractRequest.newRequest(symbol, SecType.OPT, expiry);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取涡轮合约信息 */
  public static QuoteContractResponse quoteWarContractRequest(String symbol) {
    QuoteContractRequest request = QuoteContractRequest.newRequest(symbol, SecType.WAR);
    return BasicOpenAPI.INSTANCE.request(request);
  }
}
