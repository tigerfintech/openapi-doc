/* Licensed under Apache-2.0 2025. */
package com.tigerbrokers.stock.openapi.demo.quote;

import com.tigerbrokers.stock.openapi.client.https.domain.option.model.OptionChainModel;
import com.tigerbrokers.stock.openapi.client.https.domain.option.model.OptionCommonModel;
import com.tigerbrokers.stock.openapi.client.https.domain.option.model.OptionKlineModel;
import com.tigerbrokers.stock.openapi.client.https.domain.option.model.OptionTimelineModel;
import com.tigerbrokers.stock.openapi.client.https.request.option.OptionBriefQueryV2Request;
import com.tigerbrokers.stock.openapi.client.https.request.option.OptionChainQueryV3Request;
import com.tigerbrokers.stock.openapi.client.https.request.option.OptionDepthQueryRequest;
import com.tigerbrokers.stock.openapi.client.https.request.option.OptionExpirationQueryRequest;
import com.tigerbrokers.stock.openapi.client.https.request.option.OptionKlineQueryV2Request;
import com.tigerbrokers.stock.openapi.client.https.request.option.OptionSymbolRequest;
import com.tigerbrokers.stock.openapi.client.https.request.option.OptionTimelineRequest;
import com.tigerbrokers.stock.openapi.client.https.request.option.OptionTradeTickQueryRequest;
import com.tigerbrokers.stock.openapi.client.https.response.option.OptionBriefResponse;
import com.tigerbrokers.stock.openapi.client.https.response.option.OptionChainResponse;
import com.tigerbrokers.stock.openapi.client.https.response.option.OptionDepthResponse;
import com.tigerbrokers.stock.openapi.client.https.response.option.OptionExpirationResponse;
import com.tigerbrokers.stock.openapi.client.https.response.option.OptionKlineResponse;
import com.tigerbrokers.stock.openapi.client.https.response.option.OptionSymbolResponse;
import com.tigerbrokers.stock.openapi.client.https.response.option.OptionTimelineResponse;
import com.tigerbrokers.stock.openapi.client.https.response.option.OptionTradeTickResponse;
import com.tigerbrokers.stock.openapi.client.struct.enums.Language;
import com.tigerbrokers.stock.openapi.client.struct.enums.Market;
import com.tigerbrokers.stock.openapi.client.struct.enums.OptionKType;
import com.tigerbrokers.stock.openapi.client.struct.enums.SortDir;
import com.tigerbrokers.stock.openapi.client.struct.enums.TimeZoneId;
import com.tigerbrokers.stock.openapi.demo.BasicOpenAPI;
import java.util.ArrayList;
import java.util.List;

public class OptionDemo {

  public static void main(String[] args) {
    optionExpirationQueryRequest("TSLA", Market.US);
    optionChainQueryV3Request("TSLA", "2025-09-19", Market.US, TimeZoneId.NewYork);
    optionBriefQueryV2Request("NVDA", "CALL", "175.0", "2025-09-19", TimeZoneId.NewYork);
    optionKlineQueryV2Request(
        "NVDA", "CALL", "175.0", "2025-09-19", "2025-09-16 09:59:59", "2025-09-16 12:59:59");
    optionTimelineRequest("NVDA", "CALL", "175.0", "2025-09-19");
    optionTradeTickQueryRequest("NVDA", "CALL", "175.0", "2025-09-19");
    createOptionDepthQueryRequest("NVDA", "CALL", "175.0", "2025-09-19");
    optionSymbolRequest();
  }

  /** 获取期权过期日 */
  public static OptionExpirationResponse optionExpirationQueryRequest(
      String symbol, Market market) {
    List<String> symbols = new ArrayList<>();
    symbols.add(symbol);
    OptionExpirationQueryRequest request = new OptionExpirationQueryRequest(symbols, market);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取期权链 */
  public static OptionChainResponse optionChainQueryV3Request(
      String symbol, String expiry, Market market, TimeZoneId timeZoneId) {
    // expiry 需要设置为当前周的周五
    OptionChainModel basicModel = new OptionChainModel(symbol, expiry, timeZoneId);
    OptionChainQueryV3Request request = OptionChainQueryV3Request.of(basicModel, null, market);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取期权行情摘要 */
  public static OptionBriefResponse optionBriefQueryV2Request(
      String symbol, String right, String strike, String expiry, TimeZoneId timeZoneId) {
    OptionCommonModel model = new OptionCommonModel();
    model.setSymbol(symbol);
    model.setRight(right);
    model.setStrike(strike);
    model.setExpiry(expiry, timeZoneId);
    List<OptionCommonModel> models = new ArrayList<>();
    models.add(model);
    OptionBriefQueryV2Request request = new OptionBriefQueryV2Request(models, Market.US);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取期权K线数据 */
  public static OptionKlineResponse optionKlineQueryV2Request(
      String symbol, String right, String strike, String expiry, String start, String end) {
    OptionKlineModel model = new OptionKlineModel();
    model.setSymbol(symbol);
    model.setRight(right);
    model.setStrike(strike);
    model.setExpiry(expiry, TimeZoneId.NewYork);
    model.setBeginTime(start, TimeZoneId.NewYork);
    model.setEndTime(end, TimeZoneId.NewYork);
    model.setPeriod(OptionKType.min1.getValue());
    model.setLimit(10);
    model.setSortDir(SortDir.SortDir_Descend);
    OptionKlineQueryV2Request request = OptionKlineQueryV2Request.of(model).market(Market.US);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取期权分时数据 */
  public static OptionTimelineResponse optionTimelineRequest(
      String symbol, String right, String strike, String expiry) {
    OptionTimelineModel model1 = new OptionTimelineModel();
    model1.setSymbol(symbol);
    model1.setExpiry(expiry);
    model1.setStrike(strike);
    model1.setRight(right);
    //    OptionTimelineModel model2 = new OptionTimelineModel("TCH.HK250929C00510000");
    OptionTimelineRequest request = OptionTimelineRequest.of(model1);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取期权逐笔成交数据 */
  public static OptionTradeTickResponse optionTradeTickQueryRequest(
      String symbol, String right, String strike, String expiry) {
    List<OptionCommonModel> modelList = new ArrayList<>();
    OptionCommonModel model1 = new OptionCommonModel();
    model1.setSymbol(symbol);
    model1.setExpiry(expiry);
    model1.setStrike(strike);
    model1.setRight(right);
    modelList.add(model1);
    OptionTradeTickQueryRequest request = OptionTradeTickQueryRequest.of(modelList);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取期权深度行情 */
  public static OptionDepthResponse createOptionDepthQueryRequest(
      String symbol, String right, String strike, String expiry) {
    OptionCommonModel model = new OptionCommonModel();
    model.setSymbol(symbol);
    model.setExpiry(expiry);
    model.setStrike(strike);
    model.setRight(right);
    OptionDepthQueryRequest request = OptionDepthQueryRequest.of(model).market(Market.US);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取港股期权名称 */
  public static OptionSymbolResponse optionSymbolRequest() {
    OptionSymbolRequest request = OptionSymbolRequest.newRequest(Market.HK, Language.zh_CN);
    return BasicOpenAPI.INSTANCE.request(request);
  }
}
