/* Licensed under Apache-2.0 2025. */
package com.tigerbrokers.stock.openapi.demo.quote;

import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteCapitalDistributionRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteCapitalFlowRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteDelayRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteDepthRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteHistoryTimelineRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteKlineRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteMarketRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteRealTimeQuoteRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteStockTradeRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteSymbolNameRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteSymbolRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteTimelineRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteTradeCalendarRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteTradeRankRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.QuoteTradeTickRequest;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteCapitalDistributionResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteCapitalFlowResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteDelayResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteDepthResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteHistoryTimelineResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteKlineResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteMarketResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteRealTimeQuoteResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteStockTradeResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteSymbolNameResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteSymbolResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteTimelineResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteTradeCalendarResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteTradeRankResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.QuoteTradeTickResponse;
import com.tigerbrokers.stock.openapi.client.struct.enums.CapitalPeriod;
import com.tigerbrokers.stock.openapi.client.struct.enums.KType;
import com.tigerbrokers.stock.openapi.client.struct.enums.Language;
import com.tigerbrokers.stock.openapi.client.struct.enums.Market;
import com.tigerbrokers.stock.openapi.client.struct.enums.RightOption;
import com.tigerbrokers.stock.openapi.client.struct.enums.TimeZoneId;
import com.tigerbrokers.stock.openapi.client.struct.enums.TradeSession;
import com.tigerbrokers.stock.openapi.demo.BasicOpenAPI;
import java.util.Arrays;
import java.util.List;

public class StockDemo {

  public static void main(String[] args) {
    quoteMarketRequest(Market.US);
    quoteTradeCalendarRequest(Market.US, "2025-07-20", "2025-09-30");
    quoteSymbolRequest(Market.US, false);
    quoteSymbolNameRequest(Market.US, false);
    quoteDelayRequest("AAPL", "TSLA");
    quoteTimelineRequest(1694736000000L, TradeSession.OverNight, "AAPL", "TSLA");
    quoteHistoryTimelineRequest(
        Arrays.asList("AAPL", "TSLA"), "2023-09-15", RightOption.br, TradeSession.Regular);
    quoteRealTimeQuoteRequest(Arrays.asList("AAPL", "TSLA"), true);
    quoteKlineRequestByTimeRange(
        Arrays.asList("AAPL", "TSLA"),
        KType.min1,
        "2023-09-15 09:30:00",
        "2023-09-15 16:00:00",
        TimeZoneId.NewYork,
        TradeSession.Regular,
        1000,
        RightOption.br);
    quoteKlineRequestByDate(
        Arrays.asList("AAPL", "TSLA"),
        KType.min1,
        "2025-09-23",
        TradeSession.Regular,
        RightOption.br);
    quoteDepthRequest(Arrays.asList("AAPL", "TSLA"), Market.US);
    quoteTradeTickRequest(Arrays.asList("AAPL", "TSLA"), Language.zh_CN, 5, TradeSession.Regular);
    quoteStockTradeRequest(Arrays.asList("AAPL", "TSLA"));
    quoteCapitalFlowRequest("AAPL", Market.US, CapitalPeriod.day);
    quoteCapitalDistributionRequest("AAPL", Market.US);
    quoteTradeRankRequest(Market.US, Language.zh_CN);
  }

  /** 获取市场状态 */
  public static QuoteMarketResponse quoteMarketRequest(Market market) {
    QuoteMarketRequest request = QuoteMarketRequest.newRequest(market, Language.zh_CN);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取市场交易日历 */
  public static QuoteTradeCalendarResponse quoteTradeCalendarRequest(
      Market market, String beginDate, String endDate) {
    QuoteTradeCalendarRequest request =
        QuoteTradeCalendarRequest.newRequest(market, beginDate, endDate);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取股票列表 */
  public static QuoteSymbolResponse quoteSymbolRequest(Market market, boolean includeOTC) {
    QuoteSymbolRequest request = QuoteSymbolRequest.newRequest(market).includeOTC(includeOTC);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取股票代码列表和名称 */
  public static QuoteSymbolNameResponse quoteSymbolNameRequest(Market market, boolean includeOTC) {
    QuoteSymbolNameRequest request =
        QuoteSymbolNameRequest.newRequest(market).includeOTC(includeOTC);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取股票延时行情 */
  public static QuoteDelayResponse quoteDelayRequest(String... symbols) {
    QuoteDelayRequest request = QuoteDelayRequest.newRequest(Arrays.asList(symbols));
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取分时数据 */
  public static QuoteTimelineResponse quoteTimelineRequest(
      long startTime, TradeSession session, String... symbols) {
    QuoteTimelineRequest request =
        QuoteTimelineRequest.newRequest(Arrays.asList(symbols), startTime);
    request.setTradeSession(session);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取历史分时数据 */
  public static QuoteHistoryTimelineResponse quoteHistoryTimelineRequest(
      List<String> symbols, String date, RightOption right, TradeSession session) {
    QuoteHistoryTimelineRequest request = QuoteHistoryTimelineRequest.newRequest(symbols, date);
    request.withRight(right);
    request.withTradeSession(session);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取实时行情 */
  public static QuoteRealTimeQuoteResponse quoteRealTimeQuoteRequest(
      List<String> symbols, boolean includeHourTrading) {
    QuoteRealTimeQuoteRequest request =
        QuoteRealTimeQuoteRequest.newRequest(symbols, includeHourTrading);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取kline数据 (时间范围) */
  public static QuoteKlineResponse quoteKlineRequestByTimeRange(
      List<String> symbols,
      KType kType,
      String startTime,
      String endTime,
      TimeZoneId timeZoneId,
      TradeSession session,
      int limit,
      RightOption right) {
    QuoteKlineRequest request =
        QuoteKlineRequest.newRequest(symbols, kType, startTime, endTime, timeZoneId)
            .withLimit(limit)
            .withRight(right);
    request.setTradeSession(session);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取kline数据 (固定日期 date) */
  public static QuoteKlineResponse quoteKlineRequestByDate(
      List<String> symbols, KType kType, String date, TradeSession session, RightOption right) {
    QuoteKlineRequest request =
        QuoteKlineRequest.newRequest(symbols, kType).withDate(date).withRight(right);
    request.setTradeSession(session);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取深度行情 */
  public static QuoteDepthResponse quoteDepthRequest(List<String> symbols, Market market) {
    QuoteDepthRequest request = QuoteDepthRequest.newRequest(symbols, market.name());
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取逐笔成交数据 */
  public static QuoteTradeTickResponse quoteTradeTickRequest(
      List<String> symbols, Language language, int limit, TradeSession session) {
    QuoteTradeTickRequest request = QuoteTradeTickRequest.newRequest(symbols, language, limit);
    request.setTradeSession(session);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取股票交易信息 */
  public static QuoteStockTradeResponse quoteStockTradeRequest(List<String> symbols) {
    QuoteStockTradeRequest request = QuoteStockTradeRequest.newRequest(symbols);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取股票资金流数据 */
  public static QuoteCapitalFlowResponse quoteCapitalFlowRequest(
      String symbol, Market market, CapitalPeriod period) {
    QuoteCapitalFlowRequest request = QuoteCapitalFlowRequest.newRequest(symbol, market, period);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取股票资金分布数据 */
  public static QuoteCapitalDistributionResponse quoteCapitalDistributionRequest(
      String symbol, Market market) {
    QuoteCapitalDistributionRequest request =
        QuoteCapitalDistributionRequest.newRequest(symbol, market);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取热门交易榜 */
  public static QuoteTradeRankResponse quoteTradeRankRequest(Market market, Language language) {
    QuoteTradeRankRequest request = QuoteTradeRankRequest.newRequest(market, language);
    return BasicOpenAPI.INSTANCE.request(request);
  }
}
