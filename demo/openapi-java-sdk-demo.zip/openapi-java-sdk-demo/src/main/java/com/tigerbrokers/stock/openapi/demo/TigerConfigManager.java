/* Licensed under Apache-2.0 2025. */
package com.tigerbrokers.stock.openapi.demo;

import com.tigerbrokers.stock.openapi.client.config.ClientConfig;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import lombok.Getter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Getter
public class TigerConfigManager {

  private static final Logger log = LoggerFactory.getLogger(TigerConfigManager.class);

  private static final String CONFIG_FILE_PATH = "./src/main/resources/";

  private final ClientConfig clientConfig;

  public TigerConfigManager() {
    loadConfig(CONFIG_FILE_PATH);
    this.clientConfig = initClientConfig();
  }

  private ClientConfig initClientConfig() {
    ClientConfig cfg = ClientConfig.DEFAULT_CONFIG;
    cfg.configFilePath = CONFIG_FILE_PATH;
    if (Config.getSecretKey() != null) {
      cfg.secretKey = Config.getSecretKey();
    }
    return cfg;
  }

  private String loadEnv(String envFilePath) {
    try {
      return new String(Files.readAllBytes(Paths.get(envFilePath)), StandardCharsets.UTF_8);
    } catch (IOException e) {
      log.warn("Error reading env file", e);
    }
    return "";
  }

  private void loadConfig(String basePath) {
    Properties props = new Properties();
    try (FileInputStream fis = new FileInputStream(basePath + "tiger_openapi_config.properties")) {
      props.load(fis);
    } catch (IOException e) {
      log.error("Unable to load properties file", e);
    }
    Map<String, String> map = new HashMap<>();
    for (String key : props.stringPropertyNames()) {
      map.put(key, props.getProperty(key));
    }
    Config.setConfig(map);
  }

  public static class Config {
    private static Map<String, String> values = Collections.emptyMap();

    private static void setConfig(Map<String, String> values) {
      Config.values = Collections.unmodifiableMap(new HashMap<>(values));
    }

    public static String getCustomServerUrl() {
      return values.get("customServerUrl");
    }

    public static String getCustomSocketUrl() {
      return values.get("customSocketUrl");
    }

    public static String getAccountInfo() {
      return values.get("account");
    }

    public static String getSecretKey() {
      return values.get("secretKey");
    }
  }
}
