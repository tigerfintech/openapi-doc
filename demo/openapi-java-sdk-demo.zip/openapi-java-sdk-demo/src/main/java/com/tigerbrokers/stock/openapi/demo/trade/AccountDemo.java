/* Licensed under Apache-2.0 2025. */
package com.tigerbrokers.stock.openapi.demo.trade;

import com.tigerbrokers.stock.openapi.client.https.request.TigerHttpRequest;
import com.tigerbrokers.stock.openapi.client.https.request.trade.DepositWithdrawRequest;
import com.tigerbrokers.stock.openapi.client.https.request.trade.EstimateTradableQuantityRequest;
import com.tigerbrokers.stock.openapi.client.https.request.trade.FundDetailsRequest;
import com.tigerbrokers.stock.openapi.client.https.request.trade.PositionsRequest;
import com.tigerbrokers.stock.openapi.client.https.request.trade.PrimeAnalyticsAssetRequest;
import com.tigerbrokers.stock.openapi.client.https.request.trade.PrimeAssetRequest;
import com.tigerbrokers.stock.openapi.client.https.request.trade.SegmentFundAvailableRequest;
import com.tigerbrokers.stock.openapi.client.https.request.trade.SegmentFundCancelRequest;
import com.tigerbrokers.stock.openapi.client.https.request.trade.SegmentFundHistoryRequest;
import com.tigerbrokers.stock.openapi.client.https.request.trade.SegmentFundTransferRequest;
import com.tigerbrokers.stock.openapi.client.https.response.TigerHttpResponse;
import com.tigerbrokers.stock.openapi.client.https.response.trade.DepositWithdrawResponse;
import com.tigerbrokers.stock.openapi.client.https.response.trade.EstimateTradableQuantityResponse;
import com.tigerbrokers.stock.openapi.client.https.response.trade.FundDetailsResponse;
import com.tigerbrokers.stock.openapi.client.https.response.trade.PositionsResponse;
import com.tigerbrokers.stock.openapi.client.https.response.trade.PrimeAnalyticsAssetResponse;
import com.tigerbrokers.stock.openapi.client.https.response.trade.PrimeAssetResponse;
import com.tigerbrokers.stock.openapi.client.https.response.trade.SegmentFundAvailableResponse;
import com.tigerbrokers.stock.openapi.client.https.response.trade.SegmentFundResponse;
import com.tigerbrokers.stock.openapi.client.https.response.trade.SegmentFundsResponse;
import com.tigerbrokers.stock.openapi.client.struct.enums.ActionType;
import com.tigerbrokers.stock.openapi.client.struct.enums.Currency;
import com.tigerbrokers.stock.openapi.client.struct.enums.Language;
import com.tigerbrokers.stock.openapi.client.struct.enums.Market;
import com.tigerbrokers.stock.openapi.client.struct.enums.MethodName;
import com.tigerbrokers.stock.openapi.client.struct.enums.OrderType;
import com.tigerbrokers.stock.openapi.client.struct.enums.SecType;
import com.tigerbrokers.stock.openapi.client.struct.enums.SegmentType;
import com.tigerbrokers.stock.openapi.client.util.builder.AccountParamBuilder;
import com.tigerbrokers.stock.openapi.demo.BasicOpenAPI;
import com.tigerbrokers.stock.openapi.demo.TigerConfigManager.Config;
import java.util.Collections;
import java.util.List;

public class AccountDemo {

  public static void main(String[] args) {
    String account = Config.getAccountInfo();
    accountsRequest(account);
    positionsRequest(account, SecType.STK, Market.HK);
    primeAssetRequest(account, Currency.USD);
    primeAnalyticsAssetRequest(account, SegmentType.SEC, "2025-07-01", "2025-09-20");
    segmentFundAvailableRequest(account, SegmentType.SEC, Currency.USD);
    segmentFundTransferRequest(account, SegmentType.SEC, SegmentType.FUT, Currency.HKD, 1000D);
    segmentFundCancelRequest(123456L);
    segmentFundHistoryRequest(account, 30);
    estimateTradableQuantityRequest(
        account, SecType.STK, "AAPL", ActionType.BUY, OrderType.LMT, 150D);
    depositWithdrawRequest(account, Language.en_US);
    fundDetailsRequest(
        account,
        Collections.singletonList(SegmentType.SEC.name()),
        "HKD",
        "ALL",
        "2025-01-01",
        "2025-09-01",
        0L,
        5L);
  }

  /** 账户列表 */
  public static TigerHttpResponse accountsRequest(String account) {
    TigerHttpRequest request = new TigerHttpRequest(MethodName.ACCOUNTS);
    String bizContent =
        AccountParamBuilder.instance().account(account).buildJsonWithoutDefaultAccount();
    request.setBizContent(bizContent);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 账户持仓 */
  public static PositionsResponse positionsRequest(String account, SecType secType, Market market) {
    PositionsRequest request = new PositionsRequest();
    String bizContent =
        AccountParamBuilder.instance().account(account).secType(secType).market(market).buildJson();
    request.setBizContent(bizContent);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 综合/模拟账号获取资产 */
  public static PrimeAssetResponse primeAssetRequest(String account, Currency currency) {
    PrimeAssetRequest request = PrimeAssetRequest.buildPrimeAssetRequest(account, currency);
    request.setConsolidated(Boolean.TRUE);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 综合/模拟账号获取历史资产分析数据 */
  public static PrimeAnalyticsAssetResponse primeAnalyticsAssetRequest(
      String account, SegmentType segType, String startDate, String endDate) {
    PrimeAnalyticsAssetRequest request =
        PrimeAnalyticsAssetRequest.buildPrimeAnalyticsAssetRequest(account)
            .segType(segType)
            .startDate(startDate)
            .endDate(endDate);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 综合/模拟账号获取可转出资金 */
  public static SegmentFundAvailableResponse segmentFundAvailableRequest(
      String account, SegmentType segType, Currency currency) {
    SegmentFundAvailableRequest request =
        SegmentFundAvailableRequest.buildRequest(segType, currency).account(account);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 综合/模拟账号内部资金转账 */
  public static SegmentFundResponse segmentFundTransferRequest(
      String account, SegmentType fromSeg, SegmentType toSeg, Currency currency, Double amount) {
    SegmentFundTransferRequest request =
        SegmentFundTransferRequest.buildRequest(fromSeg, toSeg, currency, amount).account(account);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 综合/模拟账号取消内部资金转账 */
  public static SegmentFundResponse segmentFundCancelRequest(Long transferId) {
    SegmentFundCancelRequest request = SegmentFundCancelRequest.buildRequest(transferId);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 综合/模拟账号内部资金转账历史记录查询 */
  public static SegmentFundsResponse segmentFundHistoryRequest(String account, int days) {
    SegmentFundHistoryRequest request =
        SegmentFundHistoryRequest.buildRequest(days).account(account);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取最大可交易数量 */
  public static EstimateTradableQuantityResponse estimateTradableQuantityRequest(
      String account,
      SecType secType,
      String symbol,
      ActionType action,
      OrderType orderType,
      Double price) {
    EstimateTradableQuantityRequest request =
        EstimateTradableQuantityRequest.buildRequest(
                secType, symbol, action, orderType, price, null)
            .account(account);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取出入金记录 */
  public static DepositWithdrawResponse depositWithdrawRequest(String account, Language lang) {
    DepositWithdrawRequest request =
        DepositWithdrawRequest.newRequest().account(account).lang(lang);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取资金明细 */
  public static FundDetailsResponse fundDetailsRequest(
      String account,
      List<String> segTypes,
      String currency,
      String fundType,
      String startDate,
      String endDate,
      Long offset,
      Long limit) {
    FundDetailsRequest request =
        FundDetailsRequest.buildFundDetailsRequest(account, segTypes, offset, limit);
    request.setCurrency(currency);
    request.setFundType(fundType);
    request.setStartDate(startDate);
    request.setEndDate(endDate);
    return BasicOpenAPI.INSTANCE.request(request);
  }
}
