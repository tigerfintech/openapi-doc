/* Licensed under Apache-2.0 2025. */
package com.tigerbrokers.stock.openapi.demo;

import com.alibaba.fastjson.JSON;
import com.tigerbrokers.stock.openapi.client.config.ClientConfig;
import com.tigerbrokers.stock.openapi.client.https.client.TigerHttpClient;
import com.tigerbrokers.stock.openapi.client.https.request.TigerRequest;
import com.tigerbrokers.stock.openapi.client.https.response.TigerResponse;
import com.tigerbrokers.stock.openapi.demo.TigerConfigManager.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BasicOpenAPI {

  public static final BasicOpenAPI INSTANCE = new BasicOpenAPI(true);

  private static final Logger log = LoggerFactory.getLogger(BasicOpenAPI.class);

  private final TigerHttpClient httpClient;

  private final boolean enableLogResponse;

  public BasicOpenAPI(boolean enableLogResponse) {
    this.enableLogResponse = enableLogResponse;

    TigerConfigManager configManager = new TigerConfigManager();
    ClientConfig clientConfig = configManager.getClientConfig();

    // init TigerHttpClient
    httpClient = TigerHttpClient.getInstance();
    if (Config.getCustomServerUrl() != null) {
      httpClient.useCustomServerUrl(Config.getCustomServerUrl());
    }
    httpClient.clientConfig(clientConfig);
  }

  public <T extends TigerResponse> T request(TigerRequest<T> request) {
    TigerResponse response = null;
    try {
      response = httpClient.execute(request);

      String responseStr = JSON.toJSONString(response);
      // 格式化输出
      //      String responseStr = JSON.toJSONString(response, SerializerFeature.PrettyFormat);
      if (response.isSuccess()) {
        if (enableLogResponse) {
          log.info(
              "Request succeeded. Request type: {}, Response type: {}, content:\n{}",
              request.getApiMethodName(),
              response.getClass().getSimpleName(),
              responseStr);
        } else {
          log.info(
              "Request succeeded. Request type: {}, Response type: {}",
              request.getApiMethodName(),
              response.getClass().getSimpleName());
        }
      } else {
        String errorMsg =
            String.format(
                "Request failed. Request type: %s, Response type: %s, content:\n%s",
                request.getApiMethodName(), response.getClass().getSimpleName(), responseStr);
        throw new RuntimeException(errorMsg);
      }
    } catch (Exception e) {
      log.error("Unexpected error during request, response: {}", response, e);
    }
    return request.getResponseClass().cast(response);
  }
}
