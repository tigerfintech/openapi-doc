/* Licensed under Apache-2.0 2025. */
package com.tigerbrokers.stock.openapi.demo.trade;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.tigerbrokers.stock.openapi.client.https.domain.contract.item.ContractItem;
import com.tigerbrokers.stock.openapi.client.https.domain.contract.model.ContractModel;
import com.tigerbrokers.stock.openapi.client.https.domain.future.item.FutureContractItem;
import com.tigerbrokers.stock.openapi.client.https.domain.trade.item.TradeOrderItem;
import com.tigerbrokers.stock.openapi.client.https.request.TigerHttpRequest;
import com.tigerbrokers.stock.openapi.client.https.request.contract.ContractRequest;
import com.tigerbrokers.stock.openapi.client.https.request.future.FutureCurrentContractRequest;
import com.tigerbrokers.stock.openapi.client.https.request.trade.QueryOrderRequest;
import com.tigerbrokers.stock.openapi.client.https.request.trade.QuerySingleOrderRequest;
import com.tigerbrokers.stock.openapi.client.https.request.trade.TradeOrderPreviewRequest;
import com.tigerbrokers.stock.openapi.client.https.request.trade.TradeOrderRequest;
import com.tigerbrokers.stock.openapi.client.https.response.TigerHttpResponse;
import com.tigerbrokers.stock.openapi.client.https.response.contract.ContractResponse;
import com.tigerbrokers.stock.openapi.client.https.response.future.FutureContractResponse;
import com.tigerbrokers.stock.openapi.client.https.response.trade.BatchOrderResponse;
import com.tigerbrokers.stock.openapi.client.https.response.trade.SingleOrderResponse;
import com.tigerbrokers.stock.openapi.client.https.response.trade.TradeOrderPreviewResponse;
import com.tigerbrokers.stock.openapi.client.https.response.trade.TradeOrderResponse;
import com.tigerbrokers.stock.openapi.client.struct.enums.ActionType;
import com.tigerbrokers.stock.openapi.client.struct.enums.Language;
import com.tigerbrokers.stock.openapi.client.struct.enums.MethodName;
import com.tigerbrokers.stock.openapi.client.struct.enums.OrderSortBy;
import com.tigerbrokers.stock.openapi.client.struct.enums.OrderType;
import com.tigerbrokers.stock.openapi.client.struct.enums.Right;
import com.tigerbrokers.stock.openapi.client.struct.enums.SecType;
import com.tigerbrokers.stock.openapi.client.struct.enums.TimeInForce;
import com.tigerbrokers.stock.openapi.client.struct.enums.TimeZoneId;
import com.tigerbrokers.stock.openapi.client.struct.enums.TradingSessionType;
import com.tigerbrokers.stock.openapi.client.util.StringUtils;
import com.tigerbrokers.stock.openapi.client.util.builder.AccountParamBuilder;
import com.tigerbrokers.stock.openapi.client.util.builder.TradeParamBuilder;
import com.tigerbrokers.stock.openapi.demo.BasicOpenAPI;
import com.tigerbrokers.stock.openapi.demo.TigerConfigManager.Config;

public class TradeDemo {

  private static final BasicOpenAPI basicOpenAPI = new BasicOpenAPI(true);

  public static void main(String[] args) {
    ContractItem contract = ContractItem.buildStockContract("TSLA", "USD");
    ActionType actionType = ActionType.BUY;
    int quantity = 1;
    double limitPrice = 100;
    String startDate = "2025-06-01 00:00:00", endDate = "2025-09-20 23:59:59";

    orderPreview(contract, actionType, quantity, limitPrice);
    //    TradeOrderItem tradeOrderItem = placeMarketOrder(contract, actionType, quantity);
    //    TradeOrderItem tradeOrderItem = placeLimitOrder(contract, actionType, quantity,
    // limitPrice);
    TradeOrderItem tradeOrderItem = placeFullTimeOrder(contract, actionType, quantity, limitPrice);
    querySingleOrder(tradeOrderItem.getId());
    queryOrderList(startDate, endDate);
    modifyOrder(quantity, limitPrice + 1, tradeOrderItem.getId(), actionType, OrderType.LMT);
    cancelOrder(tradeOrderItem.getId());
  }

  /** 市价单下单 */
  public static TradeOrderItem placeMarketOrder(
      ContractItem contract, ActionType actionType, int quantity) {
    TradeOrderRequest request = TradeOrderRequest.buildMarketOrder(contract, actionType, quantity);
    TradeOrderResponse response = BasicOpenAPI.INSTANCE.request(request);
    return response.getItem();
  }

  /** 限价单下单 */
  public static TradeOrderItem placeLimitOrder(
      ContractItem contract, ActionType actionType, int quantity, double limitPrice) {
    TradeOrderRequest request =
        TradeOrderRequest.buildLimitOrder(contract, actionType, quantity, limitPrice);
    TradeOrderResponse response = BasicOpenAPI.INSTANCE.request(request);
    return response.getItem();
  }

  /** 夜盘下单 */
  public static TradeOrderItem placeOvernightOrder(
      ContractItem contract, ActionType actionType, int quantity, double limitPrice) {
    TradeOrderRequest request =
        TradeOrderRequest.buildLimitOrder(contract, actionType, quantity, limitPrice);
    request.setTradingSessionType(TradingSessionType.OVERNIGHT);
    TradeOrderResponse response = BasicOpenAPI.INSTANCE.request(request);
    return response.getItem();
  }

  /** 夜盘下单 */
  public static TradeOrderItem placeFullTimeOrder(
      ContractItem contract, ActionType actionType, int quantity, double limitPrice) {
    TradeOrderRequest request =
        TradeOrderRequest.buildLimitOrder(contract, actionType, quantity, limitPrice);
    request.setTradingSessionType(TradingSessionType.FULL);
    TradeOrderResponse response = BasicOpenAPI.INSTANCE.request(request);
    return response.getItem();
  }

  /** 止损单下单 */
  public static TradeOrderItem placeStopOrder(
      ContractItem contract, ActionType actionType, int quantity, double auxPrice) {
    TradeOrderRequest request =
        TradeOrderRequest.buildStopOrder(contract, actionType, quantity, auxPrice);
    TradeOrderResponse response = BasicOpenAPI.INSTANCE.request(request);
    return response.getItem();
  }

  /** 止损限价单下单 */
  public static TradeOrderItem placeStopLimitOrder(
      ContractItem contract,
      ActionType actionType,
      int quantity,
      double limitPrice,
      double auxPrice) {
    TradeOrderRequest request =
        TradeOrderRequest.buildStopLimitOrder(contract, actionType, quantity, limitPrice, auxPrice);
    TradeOrderResponse response = BasicOpenAPI.INSTANCE.request(request);
    return response.getItem();
  }

  public static TradeOrderItem placeTrailOrder(
      ContractItem contract,
      ActionType actionType,
      int quantity,
      double trailingPercent,
      double auxPrice) {
    TradeOrderRequest request =
        TradeOrderRequest.buildTrailOrder(
            contract, actionType, quantity, trailingPercent, auxPrice);
    TradeOrderResponse response = BasicOpenAPI.INSTANCE.request(request);
    return response.getItem();
  }

  public static TradeOrderItem placeProfitOrder(
      ContractItem contract,
      ActionType actionType,
      int quantity,
      double limitPrice,
      double profitTakerPrice) {
    TradeOrderRequest request =
        TradeOrderRequest.buildLimitOrder(contract, actionType, quantity, limitPrice);
    TradeOrderRequest.addProfitTakerOrder(
        request, profitTakerPrice, TimeInForce.DAY, Boolean.FALSE);
    TradeOrderResponse response = BasicOpenAPI.INSTANCE.request(request);
    return response.getItem();
  }

  public static TradeOrderItem placeStopLossOrder(
      ContractItem contract,
      ActionType actionType,
      int quantity,
      double limitPrice,
      double stopLossPrice,
      TimeInForce timeInForce) {
    TradeOrderRequest request =
        TradeOrderRequest.buildLimitOrder(contract, actionType, quantity, limitPrice);
    TradeOrderRequest.addStopLossOrder(request, stopLossPrice, timeInForce);
    TradeOrderResponse response = BasicOpenAPI.INSTANCE.request(request);
    return response.getItem();
  }

  public static TradeOrderItem placeBracketsOrder(
      ContractItem contract,
      ActionType actionType,
      int quantity,
      double limitPrice,
      double profitTakerPrice,
      double stopLossPrice,
      TimeInForce timeInForce) {
    TradeOrderRequest request =
        TradeOrderRequest.buildLimitOrder(contract, actionType, quantity, limitPrice);
    TradeOrderRequest.addBracketsOrder(
        request, profitTakerPrice, timeInForce, Boolean.FALSE, stopLossPrice, timeInForce);
    TradeOrderResponse response = BasicOpenAPI.INSTANCE.request(request);
    return response.getItem();
  }

  public static TradeOrderItem placeOptionLimitOrder(
      ContractItem contract, ActionType actionType, int quantity, double limitPrice) {
    return placeLimitOrder(contract, actionType, quantity, limitPrice);
  }

  public static TradeOrderItem placeFutureLimitOrder(
      String type, ActionType actionType, int quantity, double limitPrice) {
    FutureContractResponse futureResponse =
        BasicOpenAPI.INSTANCE.request(FutureCurrentContractRequest.newRequest(type));
    FutureContractItem futureContractItem = futureResponse.getFutureContractItem();
    ContractItem contract = ContractItem.convert(futureContractItem);
    return placeLimitOrder(contract, actionType, quantity, limitPrice);
  }

  public static TradeOrderItem placeWarrantContract(
      String symbol,
      double strike,
      Right right,
      String expiry,
      ActionType actionType,
      int quantity,
      double limitPrice) {
    ContractModel contractModel = new ContractModel(symbol, SecType.WAR.name());
    contractModel.setStrike(strike);
    contractModel.setRight(right.name());
    contractModel.setExpiry(expiry);
    ContractRequest contractRequest = ContractRequest.newRequest(contractModel);
    ContractResponse contractResponse = BasicOpenAPI.INSTANCE.request(contractRequest);
    ContractItem contract = contractResponse.getItem();

    // 第二种方式，手动创建合约
    // contract = ContractItem.buildWarrantContract(symbol, expiry, strike, right.name());

    TradeOrderRequest request =
        TradeOrderRequest.buildLimitOrder(contract, actionType, quantity, limitPrice);
    TradeOrderResponse response = BasicOpenAPI.INSTANCE.request(request);
    return response.getItem();
  }

  public static TradeOrderItem placeCbbcContract(
      String symbol,
      double strike,
      Right right,
      String expiry,
      ActionType actionType,
      int quantity,
      double limitPrice) {
    ContractModel contractModel = new ContractModel(symbol, SecType.IOPT.name());
    contractModel.setStrike(strike);
    contractModel.setRight(right.name());
    contractModel.setExpiry(expiry);

    ContractRequest contractRequest = ContractRequest.newRequest(contractModel);
    ContractResponse contractResponse = BasicOpenAPI.INSTANCE.request(contractRequest);
    ContractItem contract = contractResponse.getItem();

    // 第二种方式，手动创建合约
    // contract = ContractItem.buildCbbcContract(symbol, expiry, strike, right.name());

    TradeOrderRequest request =
        TradeOrderRequest.buildLimitOrder(contract, actionType, quantity, limitPrice);
    TradeOrderResponse response = BasicOpenAPI.INSTANCE.request(request);
    return response.getItem();
  }

  public static int getOrderNo(String account) {
    TigerHttpRequest request = new TigerHttpRequest(MethodName.ORDER_NO);
    String bizContent = TradeParamBuilder.instance().account(account).buildJson();
    request.setBizContent(bizContent);
    TigerHttpResponse response = BasicOpenAPI.INSTANCE.request(request);
    if (response != null && !StringUtils.isEmpty(response.getData())) {
      return JSON.parseObject(response.getData()).getIntValue("orderId");
    }
    throw new RuntimeException("获取订单号失败:" + response.getMessage());
  }

  public static JSONObject getOrder(String account, long id) {
    TigerHttpRequest request = new TigerHttpRequest(MethodName.ORDERS);

    String bizContent = AccountParamBuilder.instance().account(account).id(id).buildJson();

    request.setBizContent(bizContent);
    TigerHttpResponse response = BasicOpenAPI.INSTANCE.request(request);
    return JSON.parseObject(response.getData());
  }

  /** 预览订单 */
  public static TradeOrderPreviewResponse orderPreview(
      ContractItem contractItem, ActionType actionType, int quantity, double limitPrice) {
    TradeOrderPreviewRequest request =
        TradeOrderPreviewRequest.buildLimitOrder(contractItem, actionType, quantity, limitPrice);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 查询订单列表 */
  public static BatchOrderResponse queryOrderList(String start, String end) {
    QueryOrderRequest request = new QueryOrderRequest();

    String bizContent =
        AccountParamBuilder.instance()
            .account(Config.getAccountInfo())
            .startDate(start, TimeZoneId.NewYork)
            .endDate(end, TimeZoneId.NewYork)
            .secType(SecType.STK)
            .sortBy(OrderSortBy.LATEST_CREATED)
            .limit(10)
            .buildJson();

    request.setBizContent(bizContent);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 查询单个订单 */
  public static SingleOrderResponse querySingleOrder(long id) {
    QuerySingleOrderRequest request = new QuerySingleOrderRequest();

    String bizContent =
        AccountParamBuilder.instance()
            .account(Config.getAccountInfo())
            .id(id)
            .isShowCharges(true)
            .lang(Language.en_US)
            .buildJson();

    request.setBizContent(bizContent);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 修改订单 */
  public static long modifyOrder(
      long totalQuantity, double limitPrice, long id, ActionType actionType, OrderType orderType) {
    TigerHttpRequest request = new TigerHttpRequest(MethodName.MODIFY_ORDER);
    String bizContent =
        TradeParamBuilder.instance()
            .account(Config.getAccountInfo())
            .totalQuantity(totalQuantity)
            .action(actionType)
            .limitPrice(limitPrice)
            .id(id)
            .orderType(orderType)
            .buildJson();
    request.setBizContent(bizContent);

    TigerHttpResponse response = BasicOpenAPI.INSTANCE.request(request);
    JSONObject data = JSON.parseObject(response.getData());
    return data.getLong("id");
  }

  /** 撤单 */
  public static TigerHttpResponse cancelOrder(long id) {
    TigerHttpRequest request = new TigerHttpRequest(MethodName.CANCEL_ORDER);
    String bizContent =
        TradeParamBuilder.instance().account(Config.getAccountInfo()).id(id).buildJson();
    request.setBizContent(bizContent);
    return BasicOpenAPI.INSTANCE.request(request);
  }
}
