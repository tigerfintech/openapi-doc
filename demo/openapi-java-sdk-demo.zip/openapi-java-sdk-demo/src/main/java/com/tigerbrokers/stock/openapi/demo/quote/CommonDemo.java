/* Licensed under Apache-2.0 2025. */
package com.tigerbrokers.stock.openapi.demo.quote;

import com.tigerbrokers.stock.openapi.client.https.request.TigerHttpRequest;
import com.tigerbrokers.stock.openapi.client.https.request.quote.KlineQuotaRequest;
import com.tigerbrokers.stock.openapi.client.https.response.TigerHttpResponse;
import com.tigerbrokers.stock.openapi.client.https.response.quote.KlineQuotaResponse;
import com.tigerbrokers.stock.openapi.client.struct.enums.MethodName;
import com.tigerbrokers.stock.openapi.client.util.builder.AccountParamBuilder;
import com.tigerbrokers.stock.openapi.demo.BasicOpenAPI;

public class CommonDemo {

  public static void main(String[] args) {
    grabQuotePermissionRequest();
    getQuotePermissionRequest();
    klineQuotaRequest();
  }

  /** 抢占行情权限 */
  public static TigerHttpResponse grabQuotePermissionRequest() {
    TigerHttpRequest request = new TigerHttpRequest(MethodName.GRAB_QUOTE_PERMISSION);
    String bizContent = AccountParamBuilder.instance().buildJson();
    request.setBizContent(bizContent);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取行情权限列表 */
  public static TigerHttpResponse getQuotePermissionRequest() {
    TigerHttpRequest request = new TigerHttpRequest(MethodName.GET_QUOTE_PERMISSION);
    String bizContent = AccountParamBuilder.instance().buildJson();
    request.setBizContent(bizContent);
    return BasicOpenAPI.INSTANCE.request(request);
  }

  /** 获取历史行情额度 */
  public static KlineQuotaResponse klineQuotaRequest() {
    return BasicOpenAPI.INSTANCE.request(KlineQuotaRequest.newRequest(Boolean.TRUE));
  }
}
