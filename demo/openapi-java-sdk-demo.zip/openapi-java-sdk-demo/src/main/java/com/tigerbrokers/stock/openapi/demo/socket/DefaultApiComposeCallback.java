/* Licensed under Apache-2.0 2025. */
package com.tigerbrokers.stock.openapi.demo.socket;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.tigerbrokers.stock.openapi.client.socket.ApiComposeCallback;
import com.tigerbrokers.stock.openapi.client.socket.data.TradeTick;
import com.tigerbrokers.stock.openapi.client.socket.data.pb.AssetData;
import com.tigerbrokers.stock.openapi.client.socket.data.pb.KlineData;
import com.tigerbrokers.stock.openapi.client.socket.data.pb.OptionTopData;
import com.tigerbrokers.stock.openapi.client.socket.data.pb.OrderStatusData;
import com.tigerbrokers.stock.openapi.client.socket.data.pb.OrderTransactionData;
import com.tigerbrokers.stock.openapi.client.socket.data.pb.PositionData;
import com.tigerbrokers.stock.openapi.client.socket.data.pb.QuoteBBOData;
import com.tigerbrokers.stock.openapi.client.socket.data.pb.QuoteBasicData;
import com.tigerbrokers.stock.openapi.client.socket.data.pb.QuoteDepthData;
import com.tigerbrokers.stock.openapi.client.socket.data.pb.StockTopData;
import com.tigerbrokers.stock.openapi.client.socket.data.pb.TickData;
import com.tigerbrokers.stock.openapi.client.struct.SubscribedSymbol;
import com.tigerbrokers.stock.openapi.client.util.ProtoMessageUtil;
import lombok.SneakyThrows;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Description: Created by lijiawen on 2018/05/23. */
public class DefaultApiComposeCallback implements ApiComposeCallback {

  private static final Logger log = LoggerFactory.getLogger(DefaultApiComposeCallback.class);

  /*股票基本行情回调*/
  @Override
  public void quoteChange(QuoteBasicData data) {
    log.info("quoteChange:" + ProtoMessageUtil.toJson(data));
  }
  /*股票最优买卖价行情回调*/
  @Override
  public void quoteAskBidChange(QuoteBBOData data) {
    log.info("quoteAskBidChange:" + ProtoMessageUtil.toJson(data));
  }

  /*期权行情回调*/
  @Override
  public void optionChange(QuoteBasicData data) {
    log.info("optionChange:" + ProtoMessageUtil.toJson(data));
  }
  /*期权最优买卖价行情回调*/
  @Override
  public void optionAskBidChange(QuoteBBOData data) {
    log.info("optionAskBidChange:" + ProtoMessageUtil.toJson(data));
  }

  /*期货行情回调*/
  @Override
  public void futureChange(QuoteBasicData data) {
    log.info("futureChange:" + ProtoMessageUtil.toJson(data));
  }
  /*期货最优买卖价行情回调*/
  @Override
  public void futureAskBidChange(QuoteBBOData data) {
    log.info("futureAskBidChange:" + ProtoMessageUtil.toJson(data));
  }

  /*深度行情回调*/
  @Override
  public void depthQuoteChange(QuoteDepthData data) {
    log.info("depthQuoteChange:" + ProtoMessageUtil.toJson(data));
  }

  @Override
  public void orderStatusChange(OrderStatusData data) {
    log.info("orderStatusChange:" + ProtoMessageUtil.toJson(data));
  }

  @Override
  public void orderTransactionChange(OrderTransactionData data) {
    log.info("orderTransactionChange:" + ProtoMessageUtil.toJson(data));
  }

  @Override
  public void positionChange(PositionData data) {
    log.info("positionChange:" + ProtoMessageUtil.toJson(data));
  }

  @Override
  public void assetChange(AssetData data) {
    log.info("assetChange:" + ProtoMessageUtil.toJson(data));
  }

  /*逐笔成交行情回调*/
  @SneakyThrows
  @Override
  public void tradeTickChange(TradeTick data) {
    log.info("tradeTickChange:" + JSON.toJSONString(data));
  }
  /*全量逐笔成交行情回调*/
  @Override
  public void fullTickChange(TickData data) {
    log.info("fullTickChange:" + ProtoMessageUtil.toJson(data));
  }
  /*分钟K线数据回调*/
  @Override
  public void klineChange(KlineData data) {
    log.info("klineChange:" + ProtoMessageUtil.toJson(data));
  }

  /** 股票行情榜单数据推送 */
  @Override
  public void stockTopPush(StockTopData data) {
    log.info("stockTopPush, market:" + data.getMarket());
  }

  /** 期权行情榜单数据推送 */
  @Override
  public void optionTopPush(OptionTopData data) {
    log.info("optionTopPush:" + JSON.toJSONString(data));
  }

  /*订阅成功回调*/
  @Override
  public void subscribeEnd(int id, String subject, String result) {
    log.info("subscribe " + subject + " end. id:" + id + ", " + result);
  }

  /*取消订阅回调*/
  @Override
  public void cancelSubscribeEnd(int id, String subject, String result) {
    log.info("cancel subscribe " + subject + " end. id:" + id + ", " + result);
  }

  /*查询已订阅symbol回调*/
  @Override
  public void getSubscribedSymbolEnd(SubscribedSymbol subscribedSymbol) {
    log.info("getSubscribedSymbolEnd:" + JSONObject.toJSONString(subscribedSymbol));
  }

  @Override
  public void error(String errorMsg) {
    log.info("error:" + errorMsg);
  }

  @Override
  public void error(int id, int errorCode, String errorMsg) {
    log.info("error:" + errorMsg);
  }

  @Override
  public void connectionClosed() {
    log.info("connectionClosed");
  }

  @Override
  public void connectionKickout(int errorCode, String errorMsg) {
    log.info("connectionKickout, errorCode:{}, errorMsg:{}", errorCode, errorMsg);
  }

  @Override
  public void connectionAck() {
    log.info("connectionAck");
  }

  @Override
  public void connectionAck(int serverSendInterval, int serverReceiveInterval) {
    log.info(
        "connectionAck, serverSendInterval:{}, serverReceiveInterval:{}",
        serverSendInterval,
        serverReceiveInterval);
  }

  @Override
  public void hearBeat(String heartBeatContent) {
    log.info("hearBeat:" + heartBeatContent);
  }

  @Override
  public void serverHeartBeatTimeOut(String channelId) {
    log.info("serverHeartBeatTimeOut:" + channelId);
  }
}
