/* Licensed under Apache-2.0 2025. */
package com.tigerbrokers.stock.openapi.demo;

import com.tigerbrokers.stock.openapi.client.config.ClientConfig;
import com.tigerbrokers.stock.openapi.client.util.ApiLogger;

public class TigerOpenClientConfig {
  static {
    ApiLogger.setEnabled(true, "./src/main/resources/");
    ClientConfig clientConfig = ClientConfig.DEFAULT_CONFIG;
    clientConfig.configFilePath = "./";
    // clientConfig.isSslSocket = true;
    // clientConfig.isAutoGrabPermission = true;
    // clientConfig.isAutoRefreshToken = true;
    // clientConfig.timeZone = TimeZoneId.Shanghai;
    // clientConfig.language = Language.en_US;
    // clientConfig.privateKey =
    // FileUtil.readPrivateKey("/Users/tiger/.ssh/rsa_private_key_test.pem");
    // clientConfig.secretKey = "xxxxxx";
  }

  public static ClientConfig getDefaultClientConfig() {
    return ClientConfig.DEFAULT_CONFIG;
  }
}
