from tigeropen.common.util.contract_utils import stock_contract
from tigeropen.common.util.order_utils import limit_order
from tigeropen.quote.quote_client import QuoteClient
from tigeropen.trade.trade_client import TradeClient
from tigeropen.tiger_open_config import TigerOpenClientConfig

def get_client_config():
    client_config = TigerOpenClientConfig(props_path='confs/myconf/')
    return client_config

client_config = get_client_config()
trade_client = TradeClient(client_config)
quote_client = QuoteClient(client_config)


def test_get_positions():
    positions = trade_client.get_positions()
    print(positions)

def test_place_order():
    contract = stock_contract(symbol='AAPL', currency='USD')
    order = limit_order(account=client_config.account,
                        contract=contract,
                        action='BUY',
                        limit_price=90.5,
                        quantity=2)
    result = trade_client.place_order(order=order)
    print(f"Order Result: {result}")

def test_quote():
    res = quote_client.get_stock_briefs(['AAPL'])
    print(res)


if __name__ == "__main__":
    test_get_positions()